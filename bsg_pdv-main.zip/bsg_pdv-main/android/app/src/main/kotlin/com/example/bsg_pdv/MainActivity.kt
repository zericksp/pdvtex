package com.example.bsg_pdv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
