import 'package:bsg_pdv/routers/cart_shop/components/List_prod_cart_shop.dart';
import 'package:bsg_pdv/routers/cart_shop/components/form_ticket.dart';
import 'package:bsg_pdv/routers/cart_shop/components/top_total.dart';
import 'package:flutter/material.dart';


class CartShop extends StatelessWidget {
  const CartShop({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Carrinho de Compras'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          const SizedBox(
            width: double.infinity,
            height: 80.0,
            child: Card(child: TopTotalCart()),
          ),
          const SizedBox(
            width: double.infinity,
            height: 250,
            child: Card(child: ListProdCartShop()),
          ),
          const Expanded(
            child: SizedBox(
              width: double.infinity,
              child: Card(
                child: FormTicket(),
              ),
            ),
          ),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
                onPressed: () {}, child: const Text('Finalizar Venda')),
          )
        ],
      ),
    );
  }
}
