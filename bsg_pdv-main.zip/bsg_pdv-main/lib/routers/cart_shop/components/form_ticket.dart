import 'package:flutter/material.dart';
import 'package:toggle_switch/toggle_switch.dart';
import 'package:date_field/date_field.dart';
import 'package:intl/intl.dart';
import 'package:bsg_pdv/store/store_pdv.dart';
import 'package:provider/provider.dart';

class FormTicket extends StatelessWidget {
  const FormTicket({super.key});

  @override
  Widget build(BuildContext context) {

    final store = Provider.of<StorePdv>(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
          child: ToggleTipoPedido(),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
          child: DateVenda(),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
          child: Text('Forma de Pagamento'),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
          child: SelectTipoPagto(),
        ),
        Visibility(
          child: Text('Só é visivel com uma condição'),
          visible: store.tipoVenda == 'E',
        ),
      ],
    );
  }
}

class ToggleTipoPedido extends StatelessWidget {
  const ToggleTipoPedido({super.key});

  @override
  Widget build(BuildContext context) {
    final store = Provider.of<StorePdv>(context);
    return ToggleSwitch(
      minWidth: 120,
      minHeight: 30,
      initialLabelIndex: 0,
      totalSwitches: 2,
      labels: const ['BALCÃO', 'ENCOMENDA'],
      onToggle: (index) {
        if (index != null) {
          store.changeTipoVenda(index);
        }
      },
    );
  }
}

class DateVenda extends StatefulWidget {
  const DateVenda({super.key});

  @override
  State<DateVenda> createState() => _DateVendaState();
}

class _DateVendaState extends State<DateVenda> {
  @override
  Widget build(BuildContext context) {
    final store = Provider.of<StorePdv>(context);
    DateTime? dataSelecionada = store.dataPedido;

    return DateTimeField(
      dateFormat: DateFormat('dd/MM/yyyy'),
      value: dataSelecionada,
      mode: DateTimeFieldPickerMode.date,
      decoration: const InputDecoration(
        labelText: 'Data do Pedido',
      ),
      onChanged: (value) {
        if (value != null) {
          store.dataPedido = value;
          setState(() {
            dataSelecionada = value;
          });
        }
      },
    );
  }
}

class SelectTipoPagto extends StatefulWidget {
  const SelectTipoPagto({super.key});

  @override
  State<SelectTipoPagto> createState() => _SelectTipoPagtoState();
}

class _SelectTipoPagtoState extends State<SelectTipoPagto> {
  @override
  Widget build(BuildContext context) {
    final store = Provider.of<StorePdv>(context);
    final List<String> tipoPagto = [
      'PIX',
      'DIN',
      'DEB01',
      'CRED01L',
      'DEB02',
      'CRED02',
      'CRED02L'
    ];
    String valorSelecionado = tipoPagto.first;

    return DropdownButton(
        value: valorSelecionado,
        isExpanded: true,
        items: tipoPagto.map((String valor) {
          return DropdownMenuItem(value: valor, child: Text(valor));
        }).toList(),
        onChanged: (String? valor) {
          if (valor != null) {
            store.changeTipoPagto(valor);
            setState(() {
              valorSelecionado = valor;
            });
          }
        });
  }
}
