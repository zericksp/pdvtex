import 'package:flutter/material.dart';

class Screen extends StatelessWidget {
  const Screen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bistro sem Glúten'),
      ),
      body: Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
        
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/pdv');
              },
              child: const Text('Ponto de Venda'),
            ),
            const SizedBox(
              height: 15,
            ),
            ElevatedButton(
              onPressed: () {},
              child: const Text('Vendas Efetuadas'),
            ),
          ],
        ),
      ),
    );
  }
}
