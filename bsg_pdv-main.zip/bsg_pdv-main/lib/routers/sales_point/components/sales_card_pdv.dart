import 'package:bsg_pdv/store/store_pdv.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SalesCardPDV extends StatelessWidget {
  const SalesCardPDV({super.key});

  @override
  Widget build(BuildContext context) {
    final store = Provider.of<StorePdv>(context);
    return Expanded(
      child: SizedBox(
        child: Card(
          margin: const EdgeInsets.all(5),
          child: Column(
            children: [
              ListTile(
                title: Text('R\$ ${store.valorCarrinho.toStringAsFixed(2)}'),
                subtitle: Text('${store.totItensCarrinho} itens'),
                leading: const Icon(Icons.point_of_sale_outlined),
                trailing: IconButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/cart_shop');
                  },
                  icon: const Icon(Icons.shopping_bag_outlined),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
