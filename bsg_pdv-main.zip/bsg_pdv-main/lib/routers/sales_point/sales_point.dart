import 'package:bsg_pdv/routers/sales_point/components/filter_cat.dart';
import 'package:bsg_pdv/routers/sales_point/components/product_list.dart';
import 'package:bsg_pdv/routers/sales_point/components/sales_card_pdv.dart';
import 'package:flutter/material.dart';

class SalesPoint extends StatelessWidget {
  const SalesPoint({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ponto de Venda'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(0, 0, 0, 4),
            height: 85,
            width: double.infinity,
            child: const SalesCardPDV(),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(0, 2, 0, 4),
            height: 40,
            width: double.infinity,
            child: const FilterCat(),
          ),
          const Expanded(
            child: SizedBox(
              width: double.infinity,
              child: ProductList(),
            ),
          ),
        ],
      ),
    );
  }
}
