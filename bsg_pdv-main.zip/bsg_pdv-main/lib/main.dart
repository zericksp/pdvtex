import 'package:bsg_pdv/routers/cart_shop/cart_shop.dart';
import 'package:bsg_pdv/routers/main_screen/main_screen.dart';
import 'package:bsg_pdv/routers/sales_point/sales_point.dart';
import 'package:bsg_pdv/store/store_pdv.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => StorePdv(),
      child: const ControlRouters(),
    ),
  );
}

class ControlRouters extends StatelessWidget {
  const ControlRouters({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      routes: {
        '/': (context) => const Screen(),
        '/pdv': (context) => const SalesPoint(),
        '/cart_shop': (context) => const CartShop(),
        //'/rota4': (context) => Rota4(title: 'Título Personalizado'),
      },
    );
  }
}
